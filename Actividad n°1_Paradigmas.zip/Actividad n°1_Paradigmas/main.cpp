#include <fstream>
#include <string.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

int main() {
  string nombreArchivo = "tex.txt";
  ifstream archivo(nombreArchivo.c_str());
  string linea, nombre, n1, n2, n3, n4;
  int res, j, i=0, lon, k=0;
  string registroNombres[100];
  float Nota_1[100], Nota_2[100], Nota_3[100], Nota_4[100];
  char b, l;
  
  // Obtener línea de archivo, y almacenar contenido en línea

  while (getline(archivo, linea)) {
    // Lo vamos imprimiendo
    //cout << "Una línea: ";
    cout << linea << endl;
    lon = linea.length();
    //cout<<" "<<lon
    for (j=0;j<lon;j++) {
      //valor = stromp(linea[j], ' ');
      l = linea[j];
      b = ' ';
      if (l != b) {
        if (i == 0)
          nombre = nombre + linea[j];
        if (i == 1)
          n1 = n1 + linea[j];
        if (i == 2)
          n2 = n2 + linea[j];
        if (i == 3)
          n3 = n3 + linea[j];
        if (i == 4)
          n4 = n4 + linea[j];
        
      }
      else {
        i++;
      }
    }

//DOS FUNCIONES QUE PUEDEN TRANSFORMAR UN STRING A NUMERO FLOAT
    float n1_float = std::stof(n1);
    //float n1_float = atof(n1);
    float n2_float = std::stof(n2);
    //float n2_float = atof(n2);
    float n3_float = std::stof(n3);
    //float n3_float = atof(n3);
    float n4_float = std::stof(n4);
    //float n4_float = atof(n4);

    registroNombres[k] = nombre;
    Nota_1[k] = n1_float;
    Nota_2[k] = n2_float;
    Nota_3[k] = n3_float;
    Nota_4[k] = n4_float;
    k++;

    
    i = 0;
    nombre = ' ';
    n1 = ' ';
    n2 = ' ';
    n3 = ' ';
    n4 = ' ';
  }
  cout<< "\n >> DATOS POR SEPARADO <<" <<endl;
  for (int p=0; p<k; p++) {
    std::cout<<registroNombres[p]<<" "<<std::endl;
    std::cout<<Nota_1[p]<<" ";
    std::cout<<Nota_2[p]<<" ";
    std::cout<<Nota_3[p]<<" ";
    std::cout<<Nota_4[p]<<std::endl;
    }
}