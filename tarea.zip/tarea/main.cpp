#include <fstream>
#include <string.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

int main() {
  string nombreArchivo = "tex.txt";
  ifstream archivo(nombreArchivo.c_str());
  string linea, nombre, n1, n2, n3, n4;
  int res, j, i=0, lon, x=0;
  string registroNombres[100];
  float Calificacion_1[100], Calificacion_2[100], Calificacion_3[100], Calificacion_4[100];
  char b, l;
  
  // CONSEGUIR LINEA DE ARCHIVO Y GUARDAMOS EN LINEA

  while (getline(archivo, linea)) {
    // IMPRIMIENDO
    cout << linea << endl;
    lon = linea.length();
    
    for (j=0;j<lon;j++) {
      l = linea[j];
      b = ' ';
      if (l != b) {
        if (i == 0)
          nombre = nombre + linea[j];
        if (i == 1)
          n1 = n1 + linea[j];
        if (i == 2)
          n2 = n2 + linea[j];
        if (i == 3)
          n3 = n3 + linea[j];
        if (i == 4)
          n4 = n4 + linea[j];
        
      }
      else {
        i++;
      }
    }

//TRANSFORMACION DE UN STRING A  FLOAT
    float n1_float = std::stof(n1);
    //float n1_float = atof(n1);
    float n2_float = std::stof(n2);
    //float n2_float = atof(n2);
    float n3_float = std::stof(n3);
    //float n3_float = atof(n3);
    float n4_float = std::stof(n4);
    //float n4_float = atof(n4);

    registroNombres[x] = nombre;
    Calificacion_1[x] = n1_float;
    Calificacion_2[x] = n2_float;
    Calificacion_3[x] = n3_float;
    Calificacion_4[x] = n4_float;
    x++;

    
    i = 0;
    nombre = ' ';
    n1 = ' ';
    n2 = ' ';
    n3 = ' ';
    n4 = ' ';
  }
  cout<< "\n >> DATOS POR SEPARADO <<" <<endl;
  for (int p=0; p<x; p++) {
    std::cout<<registroNombres[p]<<" "<<std::endl;
    std::cout<<Calificacion_1[p]<<" ";
    std::cout<<Calificacion_2[p]<<" ";
    std::cout<<Calificacion_3[p]<<" ";
    std::cout<<Calificacion_4[p]<<std::endl;
    }
}