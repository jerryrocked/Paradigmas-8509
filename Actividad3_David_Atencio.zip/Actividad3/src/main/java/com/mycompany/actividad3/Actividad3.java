/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.actividad3;

import java.util.Scanner;

/**
 *
 * @author david
 */
public class Actividad3 {

    public static void main(String[] args) {
        double Ganancia;
        double Ganancia_1;
        double Ganancia_2;  
        int Ingreso_Cliente;
        Scanner Leer = new Scanner(System.in);
        boolean Salir = false;
        int opcion;
        
        while(!Salir){
            System.out.println("==== BIENVENIDOS A BANCO XYZ ====");// MENU PARA EL USUARIO.
            System.out.println("1.- CUENTA DE AHORRO.");//CREA OPCION 1.
            System.out.println("2.- CUENTA CORRIENTE.");//CREA OPCION 2.
            System.out.println("3.- CUENTA DE PLAZO FIJO.");//CREA OPCION 3.
            System.out.println("4.- SALIR.");//CREA OPCION 4 "SALIR", EL CUAL FINALIZA EL PROGRAMA.
            System.out.println("==================================");
            System.out.print("INGRESE CANTIDAD A AHORRAR: ");//LE SOLICITA AL USUARIO QUE INGRESE LA CANTIDAD A AHORRAR.
            Ingreso_Cliente = Leer.nextInt();// LEE LA OPCION INGRESADA POR EL USUARIO.
            System.out.println("===========================================================================");
            System.out.print("SELECCIONE OPCION: ");//LE SOLICITA AL USUARIO QUE INGRESE UNA OPCION.
            opcion = Leer.nextInt();// LEE LA OPCION INGRESADA POR EL USUARIO.
          
            
            switch(opcion){ // SE CREAN LOS CASOS CON LAS DIFERENTES OPCIONES.             
                case 1:// SI EL USUARIO SELECCIONA LA OPCION 1, ESTO REALIZARA EL CALCULO NECESERIO PARA SABER LO QUE EL CLIENTE GANARA AL AÑO.
                    double cAhorro = 1.0;
                    System.out.println("===========================================================================");
                    System.out.println("HA SELECCIONADO CUENTA DE AHORRO.");
                    Ganancia = (Ingreso_Cliente*cAhorro);// CALCULA LA GANANCIA QUE TENDRA EL CLIENTE EN LA CUENTA DE AHORRO.
                    System.out.println("GANANCIA DEL CLIENTE AL AÑO EN LA CUENTA DE AHORRO ES DE: "+Ganancia);
                    System.out.println("===========================================================================");
                    break;

                case 2://// SI EL USUARIO SELECCIONA LA OPCION 2, ESTO REALIZARA EL CALCULO NECESERIO PARA SABER LO QUE EL CLIENTE GANARA AL AÑO.
                    double cCorriente = 0.5;
                    System.out.println("===========================================================================");
                    System.out.println("HA SELECCIONADO CUENTA CORRIENTE.");
                    Ganancia_1 = (Ingreso_Cliente*cCorriente);// CALCULA LA GANANCIA QUE TENDRA EL CLIENTE EN LA CUENTA CORRIENTE.
                    System.out.println("GANANCIA DEL CLIENTE AL AÑO EN LA CUENTA CORRIENTE ES DE: "+Ganancia_1);
                    System.out.println("===========================================================================");
                    break;

                case 3:// SI EL USUARIO SELECCIONA LA OPCION 3, ESTO DESPLEGARA 2 OPCIONES PARA LA CUENTA A PLAZO FIJO, SI EL USUARIO LO DESEA A 3 MESES O A 6 MESES.
                    System.out.println("===========================================================================");
                    System.out.println("HA SLECCIONADO CUENTA A PLAZO FIJO.");
                    System.out.println("==================================");
                    System.out.println("OPCION 1 = 3 MESES.");
                    System.out.println("OPCION 2 = 6 MESES.");
                    System.out.println("==================================");
                    System.out.print("SELECCIONE OPCION:");
                    int opc = Leer.nextInt();
                    
                    if(opc == 1){// SI EL USUARIO SELECCIONA LA OPCION 1 DEL MENU DE LA CUENTA A PLAZO FIJO, ESTO REALIAZARA EL CALCULO DE LA GANANCIA QUE TENDRA EL CLIENTE A 3 MESES.
                        double cPlazoFijo = 1.2;
                        System.out.println("===========================================================================");
                        System.out.println("HA SELECCIONADO CUENTA A PLAZO FIJO A 3 MESES.");
                        Ganancia_2 = (Ingreso_Cliente*cPlazoFijo)*3;// CALCULA LA GANANCIA QUE TENDRA EL CLIENTE EN LA CUENTA A PLAZO FIJO A 3 MESES.
                        System.out.println("GANANCIA DEL CLIENTE EN LA CUENTA A PLAZO FIJO EN 3 MESES ES DE: "+Ganancia_2);
                        System.out.println("===========================================================================");
                
                    }
            
                    if(opc == 2){// SI EL USUARIO SELECCIONA LA OPCION 2 DEL MENU DE LA CUENTA A PLAZO FIJO, ESTO REALIAZARA EL CALCULO DE LA GANANCIA QUE TENDRA EL CLIENTE A 6 MESES.
                        double cPlazoFijo = 1.2;
                        System.out.println("===========================================================================");
                        System.out.println("HA SELECCIONADO CUENTA A PLAZO FIJO A 6 MESES."); 
                        Ganancia_2 = (Ingreso_Cliente*cPlazoFijo)*6;// CALCULA LA GANANCIA QUE TENDRA EL CLIENTE EN LA CUENTA A PLAZO FIJO A 6 MESES.
                        System.out.println("GANANCIA DEL CLIENTE EN LA CUENTA A PLAZO FIJO EN 6 MESES ES DE: "+Ganancia_2);
                        System.out.println("===========================================================================");
                    }
                    break;

                case 4:
                    Salir=true;
                    break;
                default:// SI EL USUARIO SELECCIONA UNA OPCION QUE NO ES VALIDA, LO QUE HARA EL PROGRAMA ES VOLVELE A INDICAR QUE INGRESE NUEVAMENTE LA OPCION HASTA QUE SEA CORRECTA.
                    System.out.println("===========================================================================");;
                    System.out.println("OPCION INGRESA NO VALIDA, REINGRESE NUEVAMENTE LA OPCION...");
                    System.out.println("===========================================================================");;
           }
            
       }
        
    }
     
}
