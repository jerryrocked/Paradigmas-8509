#include <iostream>
#include <fstream>
#include <stdlib.h>
using namespace std;




class Alumno{ //En esta clase se guardarán los datos
  public: 
    int nota1, nota2, nota3, nota4;
    string nombre;
    string rut;
};



//Esta clase es la principal ya que aquí se añadirán los datos al archivo para luego ser editados en la función guardarData().
class Profesor{ 
private:
  string asignatura;
  string rut;
public:
  Profesor(string, string);
  void escribir(){
    ofstream nota;
    string datos;
    bool p =true;  
    while(p){
    nota.open("notas.txt",ios::app); 
      if(nota.fail()){
        cout<<"Error";
        exit(1);
  }
      cout<<"Digite el nombre del estudiante y sus notas: ";
      getline(cin,datos);  
      nota<<datos<<endl;
      nota.close();
      if(datos == ""){
        p = false;
        }
      }
    }
};


void guardarData(Alumno p){
  ifstream archivo("notas.txt");
  string linea, name, n1, n2, n3, n4;
  int res, j, i=0, lon;
  string arreglo[100];
  char b, l;
  int n1a = 0;
  int n;

  while(getline(archivo, linea)){
    cout<<linea<<endl;
    lon = linea.length();
    int n1a,n2a,n3a,n4a;
      for(j=0;j<lon;j++){

        l =linea[j];
        b=' ';
        if(l!=b){
          if(i==0)
            name+=linea[j];
          if(i==1)
            n1+=linea[j];
            n1a = atoi(n1.c_str());// Transformo char a int con atoi
          if(i==2)
            n2+=linea[j];
            n2a = atoi(n2.c_str());
          if(i==3)
            n3+=linea[j];
            n3a = atoi(n3.c_str());
          if(i==4)
            n4+=linea[j];
            n4a = atoi(n4.c_str());
            
        }
        else{
          arreglo[i]= name; //Aquí guardé los nombres en el array
          cout<<arreglo[i];
          i++;
        }
      }
    
    name = p.nombre;
    n1a = p.nota1;
    n2a = p.nota2;
    n3a = p.nota3;
    n4a = p.nota4;
    i=0;
    
    name = " ";
    n1= " ";
    n2= " ";
    n3= " ";
    n4= " ";
    
    }

  
}



Profesor::Profesor(string _Asignatura, string _rut){
  _rut = rut;
  _Asignatura = asignatura;
}



int main() {
  Profesor p = Profesor("hola","alo");
  p.escribir();
  Alumno c;
  guardarData(c);
  cout<<c.nombre;
  cout<<c.nota1;

  
  return 0;  
  
}

