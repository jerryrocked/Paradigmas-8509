/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject2;

/**
 *
 * @author Alumno
 */
import static java.lang.String.valueOf;
import java.util.Scanner;
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String letra;
        int cantidad;
        double interes,total;
        
        Scanner entrada=new Scanner(System.in);
        String continuar="Si";
        while ("Si".equals(continuar)){
            System.out.println("Escriba el tipo de cuenta: ");
            System.out.println("A=Ahorro (1% Anual)");
            System.out.println("B=Corriente (0.5% Anual)");
            System.out.println("C=Plazo fijo (3 o 6 meses) (1.2% Mensual)");
            letra=entrada.next();
            System.out.println("Escriba la cantidad de dinero a depositar: ");
            cantidad=entrada.nextInt();
            



            switch(letra.charAt(0)){
                case 'A':
                    interes=cantidad*0.01;
                    total=interes+cantidad;
                    System.out.println("El interés anual sería de: "+valueOf(interes));
                    System.out.println("EL total final sería de: "+valueOf(total));
                    break;
                case 'B':
                    interes=cantidad*0.005;
                    total=interes+cantidad;
                    System.out.println("El interés anual sería de: "+valueOf(interes));
                    System.out.println("EL total final sería de: "+valueOf(total));
                    break;
                case 'C':
                    System.out.println("Escriba la cantidad de meses: ");
                    int cantidad1=entrada.nextInt();
                    interes=0;
                    for(int k=0;cantidad1>k;k++){
                        interes=cantidad*0.012;
                        cantidad+=interes;

                    }
                    System.out.println("El interés sería de: "+valueOf(interes));
                    System.out.println("EL total final sería de: "+valueOf(cantidad));
                    break;



            }
        System.out.println("Escriba Si para calcular otro ahorro: ");
        continuar=entrada.next();
        }
        
    }
    
}
