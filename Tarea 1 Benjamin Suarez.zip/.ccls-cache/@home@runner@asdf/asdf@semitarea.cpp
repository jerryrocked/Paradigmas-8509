#include <iostream>
#include <cstring>
#include <string>
#include <fstream>
using namespace std;
class persona{
  public:
    string name;
    int rut;
};
class estudiante:public persona{
    
};
class profesor: public persona{

};
struct lista
{
    estudiante l[80];
    float n1[80],n2[80],n3[80],n4[80];
}typedef lista;
struct nf{
    float notaf;
    nf *siguiente;
}typedef nf;
struct seccion
{
    profesor *prof;
    lista l;
}typedef seccion;

class asignatura{
    string nombre,codigo;
    seccion secciones[2];
};
int main() {
    cout<<"Bienvenido, ingrese P si es profesor o E si es estudiante."<<endl;
    char p;
    cin>>p;
    cin.ignore();
    switch(p){
        case 'P':{
            string nombre_prof,rut_prof,archivo,linea,nom_curso,cod_curso;
            profesor prof;
            asignatura asign;
            seccion s1,s2;
            lista l1,l2;
            char*ptr;
            int k=0,i=0;
            cout<<"Ingrese su nombre: ";
            getline(cin,nombre_prof);
            cout<<"Ingrese su RUT sin puntos ni guión: ";
            getline(cin,rut_prof);
            prof.name=nombre_prof;
            prof.rut=stoi(rut_prof,nullptr);
            cout<<"Ingrese el nombre del archivo de texto: ";
            getline(cin,archivo);
            ifstream arch(archivo.c_str());
            cout<<"Ingrese el nombre del Curso: ";
            getline(cin,nom_curso);
            cout<<"Ingrese el código del Curso: ";
            getline(cin,cod_curso);
            string nom_estudiante;
            float n1,n2,n3,n4;            
            while (getline(arch,linea,' ')){
                if(k==0){
                    k++;
                    nom_estudiante=linea;
                }
                else if (k==1){
                    k++;
                    nom_estudiante=nom_estudiante+' '+linea;

                }
                else if (2==k){
                  k++;
                  n1=stof(linea);
                }
                else if (3==k){
                  k++;
                  n2=stof(linea);}
                else if(4==k){
                  k++;
                  n3=stof(linea);
                }
                else if (5==k){
                  k=0;
                  n4=stof(linea);
                }
              
            }
            
            break;
        }
        case 'E':
        break;
    }
}