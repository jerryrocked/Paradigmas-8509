#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;

class Persona
{
public:
	struct
	{
		string nom, rut, dir, telf;
		char sex;
		int edad;
	} reg;
	Persona(){};
	~Persona(){};
	void datosper();
	void mostrarper();
};
void Persona::datosper()
{
	cout << "Nombre : ";
	getline(cin, reg.nom);
	cout << "Rut : ";
	getline(cin, reg.rut);
	cout << "Direccion : ";
	getline(cin, reg.dir);
	cout << "Telefono : ";
	getline(cin, reg.telf);
	cout << "Sex : ";
	cin >> reg.sex;
	cout << "Edad : ";
	cin >> reg.edad;
};
void Persona::mostrarper()
{
	cout << "Nombre : " << reg.nom << endl;
	cout << "Rut : " << reg.rut << endl;
	cout << "Direccion : " << reg.dir << endl;
	cout << "Telefono : " << reg.telf << endl;
	cout << "Sex : ";
	cout << reg.sex << endl;
	cout << "Edad : ";
	cout << reg.edad << endl;
};

class Profesor : public virtual Persona
{
public:
	string cat;
	int cant;
	Profesor(){};
	~Profesor(){};
	void datosprof();
	void mostrarprof();
	void entregarnotas();
};

void Profesor::datosprof()
{
	int i;
	datosper();
	cin.ignore();
	cout << "Escriba la Categoria: ";
	getline(cin, cat);
};
void Profesor::mostrarprof()
{
	int i;
	mostrarper();
	cout << "Categoria : " << cat << endl;
};

class Estudiante : public virtual Persona
{
public:
	string carr;
	int can;
	Estudiante(){};
	~Estudiante(){};
	void datosest();
	void mostrarest();
};
void Estudiante::datosest()
{
	int i;
	datosper();
	cout << "Ingresar Carrera que Estudia: ";
	cin >> carr;
};
void Estudiante::mostrarest()
{
	mostrarper();
	cout << "\n Carrera: " << carr;
};

class Asignatura : public Profesor, public Estudiante
{
public:
	string s[10];
	string a[10], c[10];
	char nom[40] = "Estudiante.txt";
	int cant;
	string mat[5] = {"PROGRAMACION", "BASE DE DATOS", "ALGORITMO Y ESTRUCTURA DE DATOS", "DESARROLLO WEB Y MOVIL", "PARADIGMAS DE PROGRAMACION"};
	string cod[5] = {"PR001", "BD002", "AE003", "DM004", "PP005"};
	void ingresardatose();
	void ingresardatosp();
	void entregar_notas();
	void mostrar_notas();
	void ingresar_consola(string codigo, int seccion);
	void ingresar_txt(string codigo, int seccion);
};
void Asignatura::ingresardatosp()
{
	int opcion, opc;
	datosprof();
	cout << "Escriba la Cantidad de Asignaturas: ";
	cin >> cant;
	for (int i = 0; i < cant; i++)
	{
		cout << "Seleccione las Asignaturas: ";
		cout << "\n 1. " << mat[0];
		cout << "\n 2. " << mat[1];
		cout << "\n 3. " << mat[2];
		cout << "\n 4. " << mat[3];
		cout << "\n 5. " << mat[4];
		cout << "\n Seleccione una Opcion: ";
		cin >> opcion;
		switch (opcion)
		{
		case 1:
		{
			a[i] = mat[0];
			c[i] = cod[0];
			break;
		}
		case 2:
		{
			a[i] = mat[1];
			c[i] = cod[1];
			break;
		}
		case 3:
		{
			a[i] = mat[2];
			c[i] = cod[2];
			break;
		}
		case 4:
		{
			a[i] = mat[3];
			c[i] = cod[3];
			break;
		}
		case 5:
		{
			a[i] = mat[4];
			c[i] = cod[4];
			break;
		}
		}

		cout << "\n 1. Sección 1";
		cout << "\n 2. Sección 2";
		cout << "\n 3. Ambas secciones";
		cout << "\n Seleccione la sección: ";
		cin >> opc;
		switch (opc)
		{
		case 1:
		{
			s[i] = "1";
			break;
		}
		case 2:
		{
			s[i] = "2";
			break;
		}
		case 3:
		{
			s[i] = "3";
			break;
		}
		}
	}
};

void Asignatura::ingresardatose()
{
	int opcion, opc;
	datosest();
	cout << "Escriba la Cantidad de Asignaturas: ";
	cin >> cant;
	cin.ignore();
	for (int i = 0; i < cant; i++)
	{
		cout << "Seleccione las Asignaturas: ";
		cout << "\n 1. " << mat[0];
		cout << "\n 2. " << mat[1];
		cout << "\n 3. " << mat[2];
		cout << "\n 4. " << mat[3];
		cout << "\n 5. " << mat[4];
		cout << "\n Seleccione una Opcion: ";
		cin >> opcion;
		switch (opcion)
		{
		case 1:
		{
			a[i] = mat[0];
			c[i] = cod[0];
			break;
		}
		case 2:
		{
			a[i] = mat[1];
			c[i] = cod[1];
			break;
		}
		case 3:
		{
			a[i] = mat[2];
			c[i] = cod[2];
			break;
		}
		case 4:
		{
			a[i] = mat[3];
			c[i] = cod[3];
			break;
		}
		case 5:
		{
			a[i] = mat[4];
			c[i] = cod[4];
			break;
		}
		}
		cout << "\n 1. Sección 1";
		cout << "\n 2. Sección 2";
		cout << "\n Seleccione la Sección: ";
		cin >> opc;
		switch (opc)
		{
		case 1:
		{
			s[i] = "1";
			break;
		}
		case 2:
		{
			s[i] = "2";
			break;
		}
		}
	}
};
// Con esta funcion el estudiante puede consultar las notas, en caso de que no hayan sido subidas aún, muestra por pantalla que no han sido subidas.
void Asignatura::mostrar_notas()
{
	ingresardatose();
	string txt, linea, aux, notas;
	int opcion, q = 0;
	notas = reg.nom + ".txt";
	ofstream archivonotas(notas.c_str());
	for (int m = 0; m < cant; m++)
	{
		archivonotas << a[m] << " ";
		cout << m + 1 << ". " << a[m] << endl;
		txt = c[m] + s[m] + ".txt";
		ifstream archivo(txt.c_str());
		while (std::getline(archivo, linea))
		{
			q = 1;
			if (reg.nom.compare(0, reg.nom.length(), linea) <= 0)
			{
				aux = linea.substr(reg.nom.length() + 1, 20);
				cout << "Su nota final es: " << aux << endl;
				archivonotas << aux;
				if (stof(aux) >= 4.0)
				{
					archivonotas << " Aprobado \n";
				}
				else
				{
					archivonotas << " Reprobado \n";
				}
				break;
			}
		}
		if (q == 0)
		{
			archivonotas << " Las notas de este ramo aún no han sido publicadas. \n";
			cout << "Las notas de este ramo aún no han sido publicadas. \n";
		}
		archivo.close();
		q = 0;
	}
}
// con esta función el profesor ingresa las notas, da opción para hacerlo por pantalla o por txt
void Asignatura::entregar_notas()
{
	ingresardatosp();
	int opcion, q = 0, metodo, seccion;
	char y = 's';
	while (y == 's')
	{
		cout << "Seleccione materia para ingresar las notas: \n";
		for (int m = 0; m < cant; m++)
		{
			cout << m + 1 << ". " << a[m] << endl;
		}
		cin >> opcion;
		opcion--;
		seccion = stoi(s[opcion]);
		if (seccion == 3)
		{
			cout << "Elija sección: ";
			cin >> seccion;
		}
		cout << "Elija método para ingresar notas: \n"
			 << "1. Por pantalla\n"
			 << "2. Por archivo de texto\n";
		cin >> metodo;
		switch (metodo)
		{
		case 1:
			ingresar_consola(c[opcion], seccion);
			break;

		case 2:
			ingresar_txt(c[opcion], seccion);
			break;
		}
		cout << "Desea ingresar otra materia? s para sí, cualquier otra tecla para no\n";
		cin >> y;
	}
}
// esta estructura de datos se hizo para poder realizar de forma más fácil el proceso de subida de notas
struct Seccion
{
	string nom[40];//nombre de los alumnos
	int cant, aprobados = 0, ns;//cantidad de alumnos totales, aprobados y el numero de seccion
	float n1[40], n2[40], n3[40], n4[40], nf[40];//arrays de las notas de cada alumno
	int lista[40];//lista que se usa para el ordenamiento de nota máxima
} typedef Seccion;
// esta funcion asigna memoria a una estructura de datos para poder utilizarla
Seccion *Crear_seccion()
{
	Seccion *sec;
	sec = (Seccion *)malloc(sizeof(Seccion));
	for (int g = 0; g < 40; g++)
	{
		sec->lista[g] = 0;
	}
	return sec;
}
// Esta funcion genera un archivo de texto a partir de la estructura de datos y el código de un curso.
void generartxt(string codigo, Seccion *sec)
{
	string nombre_txt = codigo + to_string(sec->ns) + ".txt";
	ofstream archivo(nombre_txt.c_str());
	int contador = 0;
	float notamax;
	int posicion;
	while (contador < sec->cant)
	{
		notamax = 0;
		for (int k = 0; k < sec->cant; k++)
		{
			if (notamax <= sec->nf[k] && sec->lista[k] == 1)
			{
				notamax = sec->nf[k];
				posicion = k;
			}
		}
		sec->lista[posicion] = 0;
		archivo << sec->nom[posicion] << " " << sec->nf[posicion] << endl;
		cout << sec->nom[posicion] << " " << sec->nf[posicion] << endl;
		contador++;
	}
	cout << "Aprobados: " << sec->aprobados << endl;
	cout << "Reprobados: " << (sec->cant - sec->aprobados) << endl;
}
// esta funcion maneja todo el proceso de ingresar por consola.
void Asignatura::ingresar_consola(string codigo, int seccion)
{
	char y = 's';
	int indice = 0;
	string aux;
	Seccion *sec = Crear_seccion();
	sec->ns = seccion;
	while (y == 's')
	{
		cout << "Ingrese el nombre del estudiante: ";
		cin.ignore();
		getline(cin, aux);
		sec->nom[indice] = aux;
		cout << "Ingrese la nota 1: ";
		cin >> sec->n1[indice];
		cout << "Ingrese la nota 2: ";
		cin >> sec->n2[indice];
		cout << "Ingrese la nota 3: ";
		cin >> sec->n3[indice];
		cout << "Ingrese la nota 4: ";
		cin >> sec->n4[indice];
		sec->nf[indice] = (sec->n1[indice] + sec->n2[indice] + sec->n3[indice] + sec->n4[indice]) / 4;
		if (sec->nf[indice] >= 4)
			sec->aprobados++;
		sec->lista[indice] = 1;
		sec->cant++;
		cout << "Desea ingresar otro estudiante?\n Ingrese s para sí o cualquier otra letra para no: ";
		cin >> y;
		indice++;
	}
	generartxt(codigo, sec);
}
// esta funcion maneja todo el proceso de ingresar por archivo de texto.
void Asignatura::ingresar_txt(string codigo, int seccion)
{
	string linea,aux;
	Seccion *sec = Crear_seccion();
	int pos, cant = 0;
	cout << "Ingrese el nombre del archivo con las notas (con extensión del archivo): ";
	cin.ignore();
  sec->ns=seccion;
	getline(cin, linea);
	ifstream arch(linea.c_str());
	while (getline(arch, linea))
	{
		pos = linea.find(" ", 0) + 1;
		pos = linea.find(" ", pos);
    aux = linea.substr(0, pos + 1);
		sec->nom[cant] = aux;
		linea = linea.substr(pos, 30);
		sec->n1[cant] = stof(linea.substr(0, 3));
		sec->n2[cant] = stof(linea.substr(4, 3));
		sec->n3[cant] = stof(linea.substr(8, 3));
		sec->n4[cant] = stof(linea.substr(12, 3));
		sec->cant = sec->cant + 1;
		sec->nf[cant] = (sec->n1[cant] + sec->n2[cant] + sec->n3[cant] + sec->n4[cant]) / 4;
		if (sec->nf[cant] >= 4.0)
			sec->aprobados++;
		sec->lista[cant] = 1;
		cant++;
	}

	generartxt(codigo, sec);
}
int main(int argc, char **argv)
{
	Asignatura as;
	int opc;
	cout << "Sistema de Notas \n";
	cout << "1. Profesor: \n";
	cout << "2. Estudiante: \n";
	cout << "3. Salir \n";
	cout << "Seleccionar Opción: ";
	cin >> opc;
	cin.ignore();
	switch (opc)
	{
	case 1:
		as.entregar_notas();
		break;
	case 2:
		as.mostrar_notas();
		break;
	case 3:
		cout << "Saliendo del sistema";
		break;
	}

	return 0;
}
