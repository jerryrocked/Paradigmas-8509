Estimado profesor:
Mi programa sólo funciona en replit, dado que el tratamiento de archivos con Visual Studio no me funcionaba.
Acepta de input los floats de la siguiente forma:
a.b con solo un decimal de de precisión, también, los outputs son de la forma que aparece en la tarea.
No recibe ruts de alumno cuando el profesor ingresa los datos, dado que no estaba de ejemplo en el input que aparece en la tarea.
Fuera de esos comentarios, funciona perfecto la tarea.