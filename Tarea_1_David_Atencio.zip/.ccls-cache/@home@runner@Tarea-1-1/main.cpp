#include <iostream>
#include <fstream>
#include <cstring>
#include <string.h>
#include <stdio.h>
using namespace std;

class Persona
{
	public:
	struct {
		string nom,apellido,rut,dir,telf,sex;
		int edad;
	}registro;	
	Persona(){ };
	~Persona(){ };
	void datosper();
	void MostrarPersona();
};
void Persona::datosper(){
  cout <<"=======================";
	cout << "\nNombre: ";   
	cin >> registro.nom;
	cout << "Apellido: "; 
	cin >> registro.apellido;
    cout << "Rut: "; 
    cin >>  registro.rut;
    cout << "Direccion: "; 
    cin >> registro.dir;
    cout << "Telefono: "; 
    cin >> registro.telf;
    cout << "Sexo: "; 
    cin >> registro.sex;
	  cout << "Edad: "; 
	  cin>> registro.edad;
	};
void Persona::MostrarPersona(){
	  cout << "Nombre: "<<registro.nom<<endl;
    cout << "Apellido: "<<registro.apellido<<endl;
    cout << "Rut: "<<registro.rut<<endl;
    cout << "Direccion: "<<registro.dir<<endl;
    cout << "Telefono: "<<registro.telf<<endl;
    cout << "Sexo: "<<registro.sex<<endl;
    cout << "Edad: "<<registro.edad<<endl;
	};

class Profesor: public virtual Persona
{
	public:
	string cat;
	int cant;
	Profesor(){	};
	~Profesor(){ };
	void DatosProfesor();
	void MostrarDatosProf();
	void EntregaNotas();
};

void Profesor::DatosProfesor() {
		int i;
		datosper();
		cin.ignore();
		cout<<"ESCRIBA LA CATEGORIA: ";getline(cin, cat);	
	};
void Profesor::MostrarDatosProf(){
		int i;
		MostrarPersona();
		cout << "CATEGORIA : "<<cat<<endl;
	};

class Estudiante: public virtual Persona
{
	public:
	string carr;
	int can;
	Estudiante(){ };
	~Estudiante(){ };
	void datosest();
	void mostrarest();
};
void Estudiante::datosest() {
		int i;
		datosper();
		cout<<"INGRESAR CARRERA QUE ESTUDIA:";
		cin>>carr;
	};
void Estudiante::mostrarest(){
		MostrarPersona();
		cout<<"CARRERA: \n"<<carr;
	};
	
class Asignatura: public Profesor, public Estudiante
{
	public:
	int n;
	float notas[10],promedio;
	string s[10];
	string a[10],c[10];
	string mat[5]={"PROGRAMACION","BASE DE DATOS","ALGORITMO Y ESTRUCTURA DE DATOS","DESARROLLO WEB Y MOBIL","PARADIGMAS DE PROGRAMACION"};
	string cod[5]={"PR001","BD002","AE003","DM004","PP005"};
	Asignatura(){ };
	~Asignatura(){ };
	void IngresarDatosEst();
	void crearArchivoEst();
	void IngresarDatosProf();
	void mostrarp();
    void Ingresar_NotasEst();
    void Mostrar_NotasEst();
    void crearArchivoProf();

};

void Asignatura::Ingresar_NotasEst(){
	for(int i=0;i<5;i++){        
    	cout<<"INGRESE NOTAS DEL ESTUDIANTE: ";
    	cin>>notas[i];
    }
 
};
  /*Guarda la cantidad y el nombre de asignaturas(archivos)
    para darselas a la variable de alumnos.*/

void Asignatura::Mostrar_NotasEst(){
	cout<<"\n";
  	cout<<"NOTA 1:"<<notas[0]<<endl;
  	cout<<"NOTA 2:"<<notas[1]<<endl;
  	cout<<"NOTA 3:"<<notas[2]<<endl;
  	cout<<"NOTA 4:"<<notas[3]<<endl;
  	cout<<"NOTA 5:"<<notas[4]<<endl;

};
	

void Asignatura::mostrarp(){
		MostrarDatosProf();
		cout << "CANTIDAD DE ASIGNATURAS : "<<cant<<endl;
		cout<<"ASIGNATURAS: \n";	
		for(int i=0;i<cant;i++){
			cout<<a[i]<<endl;
		}
};
void Asignatura::IngresarDatosProf(){
	int opcion,opc;
	DatosProfesor();
	cout<<"INGRESE LA CANTIDAD DE ASIGNATURAS: ";cin>> cant;
	for (int i=0;i<cant;i++){
		cout<<"SELECCIONE LAS ASIGNATURAS: ";
		cout<<"\n 1. "<<mat[0];
		cout<<"\n 2. "<<mat[1];
		cout<<"\n 3. "<<mat[2];
		cout<<"\n 4. "<<mat[3];
		cout<<"\n 5. "<<mat[4];
		cout<<"\n SELECCIONE UNA OPCION: ";
		cin>>opcion;
		switch (opcion){
			case 1: {
			a[i]=mat[0];
			c[i]=cod[0];
			break;
			}
			case 2: {
			a[i]=mat[1];
			c[i]=cod[1];
			break;
			}
			case 3: {
			a[i]=mat[2];
			c[i]=cod[2];
			break;
			}
			case 4: {
			a[i]=mat[3];
			c[i]=cod[3];
			break;
			}
			case 5: {
			a[i]=mat[4];
			c[i]=cod[4];
			break;
			}
			}
		
		cout<<"\n 1. SECCION 1";
		cout<<"\n 2. SECCION 2";
		cout<<"\n SELECCIONE UNA SECCION: ";			
		cin>>opc;
		switch (opc){
			case 1: {
				s[i]="1";
				break;
			}
			case 2: {
				s[i]="2";
				break;
			}
		}
 	}
};


void Asignatura::IngresarDatosEst(){
	int opcion,opc;
	datosest();
	cout<<"INGRESE CANTIDAD DE ASIGNATURAS: ";cin>> cant;
	for (int i=0;i<cant;i++){
		cout<<"SELECCIONE LAS ASIGNATURAS: ";
		cout<<"\n 1. "<<mat[0];
		cout<<"\n 2. "<<mat[1];
		cout<<"\n 3. "<<mat[2];
		cout<<"\n 4. "<<mat[3];
		cout<<"\n 5. "<<mat[4];
		cout<<"\n SELECCIONE UNA OPCION: ";
		cin>>opcion;
		switch (opcion){
		case 1: {
			a[i]=mat[0];
			c[i]=cod[0];
			break;
		}
		case 2: {
			a[i]=mat[1];
			c[i]=cod[1];
			break;
		} 
		case 3: {
			a[i]=mat[2];
			c[i]=cod[2];
			break;
		} 
		case 4: {
			a[i]=mat[3];
			c[i]=cod[3];
			break;
		} 
		case 5: {
			a[i]=mat[4];
			c[i]=cod[4];
			break;
		} 
		}
		cout<<"\n 1. SECCION 1";
		cout<<"\n 2. SECCION 2";
		cout<<"\n SELECCIONE LA SECCION: ";			
		cin>>opc;
		switch (opc){
			case 1: {
				s[i]="1";
				break;
			}
			case 2: {
				s[i]="2";
				break;
			}
		}
	}
}; 

void Asignatura::crearArchivoEst(){
	mostrarest();
    datosper();
    int i;
    ofstream archivo;
    promedio = notas[0]+notas[1]+notas[2]+notas[3]+notas[4] ;
	promedio = promedio/5;
    archivo.open("DatosAlumno.txt",ios::out);
    archivo<<"NOMBRE ESTUDIANTE:"<<registro.nom<<endl;
    archivo<<"APELLIDO ESTUDIANTE:"<<registro.apellido<<endl;
    archivo<<"RUT ESTUDIANTE:"<<registro.rut<<endl;
    archivo<<"DIRECCION ESTUDIANTE:"<<registro.dir<<endl;
    archivo<<"TELEFONO ESTUDIANTE:"<<registro.telf<<endl;
    archivo<<"SEXO ESTUDIANTE:"<<registro.sex<<endl;
    archivo<<"EDAD ESTUDIANTE:"<<registro.edad<<endl;
    archivo<<"ASIGNATURA 1: "<<a[0]<<" "<<"CODIGO 1 :"<<c[0]<<endl;
    archivo<<"ASIGNATURA 2: "<<a[1]<<" "<<"CODIGO 2 :"<<c[1]<<endl;
    archivo<<"ASIGNATURA 3: "<<a[2]<<" "<<"CODIGO 3 :"<<c[2]<<endl;
    archivo<<"ASIGNATURA 4: "<<a[3]<<" "<<"CODIGO 4 :"<<c[3]<<endl;
    archivo<<"ASIGNATURA 5: "<<a[4]<<" "<<"CODIGO 5 :"<<c[4]<<endl;
	archivo<<"SECCION:"<<s[0]<<" "<<s[1]<<endl;
    archivo<<"NOTA 1:"<<notas[0]<<" "<<"NOTA 2: "<<notas[1]<<" "<<"NOTA 3: "<<notas[2]<<" "<<"NOTA 4: "<<notas[3]<<" "<<"NOTA 5: "<<notas[4]<<endl;
    archivo<<"EL PROMEDIO ES DE: "<<promedio<<endl;
  

};

void Asignatura::crearArchivoProf(){
	mostrarest();
    ofstream archivo;
  
    archivo.open("DatosProfe.txt",ios::out);
    archivo<<"NOMBRE PROFESOR:"<<registro.nom<<endl;
    archivo<<"APELLIDO PROFESOR:"<<registro.apellido<<endl;
    archivo<<"RUT PROFESOR:"<<registro.rut<<endl;
    archivo<<"DIRECCION PROFESOR:"<<registro.dir<<endl;
    archivo<<"TELEFONO PROFESOR:"<<registro.telf<<endl;
    archivo<<"SEXO PROFESOR:"<<registro.sex<<endl;
    archivo<<"EDAD PROFESOR:"<<registro.edad<<endl;
	archivo<<"ASIGNATURA 1: "<<a[0]<<" "<<"CODIGO 1: "<<c[0]<<endl;
    archivo<<"ASIGNATURA 2:"<<a[1]<<" "<<"CODIGO 2: "<<c[1]<<endl;
    archivo<<"ASIGNATURA 3:"<<a[2]<<" "<<"CODIGO 3: "<<c[2]<<endl;
    archivo<<"ASIGNATURA 4:"<<a[3]<<" "<<"CODIGO 4: "<<c[3]<<endl;
    archivo<<"ASIGNATURA 5:"<<a[4]<<" "<<"CODIGO 5: "<<c[4]<<endl;
	archivo<<"SECCION: "<<s[0]<<" "<<s[1]<<endl;
};

int main() {
	Asignatura asig;
	int opc;
  int opc2;
  int opc3;
    do {
        cout <<"======================";
        cout << "\n    MENU:";
        cout <<"\n1- PROFESOR.";
        cout <<"\n2- ESTUDIANTE.";
        cout <<"\n3- SALIR";
        cout <<"\n======================";
        cout <<"\n SELECCIONE OPCION : ";
        cin >> opc;
        switch(opc) {

          case 1:
            cout <<"\n======================";
            cout<<"\n1.- INGRESAR DATOS DEL PROFESOR.";
            cout<<"\n2.- CREAR ARCHIVO CON DATOS DEL PROFESOR.";
            cout<<"\n3.- CREAR ARCHIVO CON DATOS DEL ALUMNO.";
            cout<<"\n SELECCIONE OPCION: ";
            cin>>opc2;
            switch(opc2) { 
                 case 1:
                  asig.IngresarDatosProf();
                  break;

                 case 2:
                  asig.crearArchivoProf();
                  break;

                 case 3:
                  asig.crearArchivoEst();
                  asig.Ingresar_NotasEst();
                  
                  break;
               }
               break;

          

          case 2:
            cout <<"\n======================";
            cout<<"\n1- INGRESAR DATOS DEL ALUMNO.";
			      cout<<"\n2- CREAR ARCHIVO ALUMNO.";
            cout<<"\n SELECCIONE OPCION: ";
            cin>>opc3;
            switch(opc3) { 
                 case 1:
                  asig.IngresarDatosEst();	
                  asig.Ingresar_NotasEst();
                  break;

                 case 2:
                  asig.crearArchivoEst();
                  break; 
               }
               break;
        }
    } while(opc!=0);
  system("PAUSE" );
  return 0;

}