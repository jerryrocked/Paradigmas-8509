#include <iostream>
#include <fstream>
#include <cstring>
#include <string.h>
#include <stdio.h>
using namespace std;

class Sujeto
{
	public:
	struct {
		string Nombre,Rut;
		int Edad;
	}reg;	
	Sujeto(){ };
	~Sujeto(){ };
	void datosSujeto();
	void mostrarSujeto();
};
void Sujeto::datosSujeto(){
	cout << "Nombre : "; cin >> reg.Nombre;
  cout << "Rut : "; cin >>  reg.Rut;
	cout << "Edad : "; cin>> reg.Edad;
	};
void Sujeto::mostrarSujeto(){
	cout << "Nombre : "<<reg.Nombre<<endl;
    cout << "Rut : "<<reg.Rut<<endl;
    cout << "Edad : "<<reg.Edad<<endl;
	};

class Profe: public virtual Sujeto
{
	public:
	string cat;
	int cant;
	Profe(){	};
	~Profe(){ };
	void DatosProfe();
	void MostrarProfe();
	void Entregade();
};

void Profe::DatosProfe() {
		int i;
		datosSujeto();
		cin.ignore();
		cout<<"Escriba la Categoria: ";getline(cin, cat);	
	};
void Profe::MostrarProfe(){
		int i;
		mostrarSujeto();
		cout << "Categoria : "<<cat<<endl;
	};

class Alumno: public virtual Sujeto
{
	public:
	string Carr;
	int can;
	Alumno(){ };
	~Alumno(){ };
	void DatosAlum();
	void MostrarAlum();
};
void Alumno::DatosAlum() {
		int i;
		datosSujeto();
		cout<<"Ingresar Carrera que esta cursando:";
		cin>>Carr;
	};
void Alumno::MostrarAlum(){
		mostrarSujeto();
		cout<<" Carrera: \n"<<Carr;
	};
	
class Ramo: public Profe, public Alumno
{
	public:
	int n;
	float Notas[10],Promedio;
	string s[10];
	string a[10],c[10];
	string mat[5]={"PROGRAMACION","BASE DE DATOS","ALGORITMOS Y ESTRUCTURA DE DATOS","DESARROLLO WEB Y MOVIL","PARADIGMAS DE PROGRAMACION"};
	string cod[5]={"PR001","BD002","AE003","DM004","PP005"};
	Ramo(){ };
	~Ramo(){ };
	void IngresarDatosE();
	void CrearArchivoE();
	void IngresarDatosP();
	void MostrarP();
  void IngresarNotasE();
  void MostrarNotasE();
  void CrearArchivoP();

};

void Ramo::IngresarNotasE(){
	for(int i=0;i<5;i++){        
    	cout<<"Ingrese la nota:";
    	cin>>Notas[i];
    }
 
};
  /*Guarda la cantidad y el Nombre de ramos(archivos)
    para darselas a la variable de alumnos.*/

void Ramo::MostrarNotasE(){
	cout<<"\n";
  	cout<<"nota1:"<<Notas[0]<<endl;
  	cout<<"nota2:"<<Notas[1]<<endl;
  	cout<<"nota3:"<<Notas[2]<<endl;
  	cout<<"nota4:"<<Notas[3]<<endl;
  	cout<<"nota5:"<<Notas[4]<<endl;

};
	

void Ramo::MostrarP(){
		MostrarProfe();
		cout << "Cantidad Ramo : "<<cant<<endl;
		cout<<"Ramos: \n";	
		for(int i=0;i<cant;i++){
			cout<<a[i]<<endl;
		}
};
void Ramo::IngresarDatosP(){
	int opcion,opc;
	DatosProfe();
	cout<<"Escriba la Cantidad de Ramos: ";cin>> cant;
	for (int i=0;i<cant;i++){
		cout<<"Seleccione las Ramos: ";
		cout<<"\n 1. "<<mat[0];
		cout<<"\n 2. "<<mat[1];
		cout<<"\n 3. "<<mat[2];
		cout<<"\n 4. "<<mat[3];
		cout<<"\n 5. "<<mat[4];
		cout<<"\n Seleccione una Opcion: ";
		cin>>opcion;
		switch (opcion){
			case 1: {
			a[i]=mat[0];
			c[i]=cod[0];
			break;
			}
			case 2: {
			a[i]=mat[1];
			c[i]=cod[1];
			break;
			}
			case 3: {
			a[i]=mat[2];
			c[i]=cod[2];
			break;
			}
			case 4: {
			a[i]=mat[3];
			c[i]=cod[3];
			break;
			}
			case 5: {
			a[i]=mat[4];
			c[i]=cod[4];
			break;
			}
			}
		
		cout<<"\n 1. Seccion 1";
		cout<<"\n 2. Seccion 2";
		cout<<"\n Seleccione la Seccion: ";			
		cin>>opc;
		switch (opc){
			case 1: {
				s[i]="1";
				break;
			}
			case 2: {
				s[i]="2";
				break;
			}
		}
 	}
};


void Ramo::IngresarDatosE(){
	int opcion,opc;
	DatosAlum();
	cout<<"Escriba la Cantidad de Ramos: ";cin>> cant;
	for (int i=0;i<cant;i++){
		cout<<"Seleccione las Ramos: ";
		cout<<"\n 1. "<<mat[0];
		cout<<"\n 2. "<<mat[1];
		cout<<"\n 3. "<<mat[2];
		cout<<"\n 4. "<<mat[3];
		cout<<"\n 5. "<<mat[4];
		cout<<"\n Seleccione una Opcion: ";
		cin>>opcion;
		switch (opcion){
		case 1: {
			a[i]=mat[0];
			c[i]=cod[0];
			break;
		}
		case 2: {
			a[i]=mat[1];
			c[i]=cod[1];
			break;
		} 
		case 3: {
			a[i]=mat[2];
			c[i]=cod[2];
			break;
		} 
		case 4: {
			a[i]=mat[3];
			c[i]=cod[3];
			break;
		} 
		case 5: {
			a[i]=mat[4];
			c[i]=cod[4];
			break;
		} 
		}
		cout<<"\n 1. Seccion 1";
		cout<<"\n 2. Seccion 2";
		cout<<"\n Seleccione la Seccion: ";			
		cin>>opc;
		switch (opc){
			case 1: {
				s[i]="1";
				break;
			}
			case 2: {
				s[i]="2";
				break;
			}
		}
	}
}; 

void Ramo::CrearArchivoE(){
	MostrarAlum();
  datosSujeto();
  int i;
  ofstream archivo;
  Promedio = Notas[0]+Notas[1]+Notas[2]+Notas[3]+Notas[4] ;
	Promedio = Promedio/5;
  archivo.open("DatosAlumno.txt",ios::out);
  archivo<<"NOMBRE DE ESTUDIANTE:"<<reg.Nombre<<endl;
  archivo<<"RUT DE ESTUDIANTE:"<<reg.Rut<<endl;
  archivo<<"EDAD DE ESTUDIANTE:"<<reg.Edad<<endl;
	archivo<<"Ramo1:"<<a[0]<<" "<<"CODIGO1:"<<c[0]<<endl;
  archivo<<"Ramo2:"<<a[1]<<" "<<"CODIGO2:"<<c[1]<<endl;
  archivo<<"Ramo3:"<<a[2]<<" "<<"CODIGO3:"<<c[2]<<endl;
  archivo<<"Ramo4:"<<a[3]<<" "<<"CODIGO4:"<<c[3]<<endl;
  archivo<<"Ramo5:"<<a[4]<<" "<<"CODIGO5:"<<c[4]<<endl;
	archivo<<"SECCION:"<<s[0]<<" "<<s[1]<<endl;
  archivo<<"NOTA1:"<<Notas[0]<<" "<<"NOTA2:"<<Notas[1]<<" "<<"NOTA3:"<<Notas[2]<<" "<<"NOTA4:"<<Notas[3]<<" "<<"NOTA5:"<<Notas[4]<<endl;
  archivo<<"EL PROMEDIO ES DE:"<<Promedio<<endl;
  

};

void Ramo::CrearArchivoP(){
	MostrarAlum();
  ofstream archivo;
  
  archivo.open("DatosProfe.txt",ios::out);
  archivo<<"NOMBRE DE PROFESOR:"<<reg.Nombre<<endl;
  archivo<<"RUT DE PROFESOR:"<<reg.Rut<<endl;
  archivo<<"EDAD DE PROFESOR:"<<reg.Edad<<endl;
	archivo<<"Ramo1:"<<a[0]<<" "<<"CODIGO1:"<<c[0]<<endl;
  archivo<<"Ramo2:"<<a[1]<<" "<<"CODIGO2:"<<c[1]<<endl;
  archivo<<"Ramo3:"<<a[2]<<" "<<"CODIGO3:"<<c[2]<<endl;
  archivo<<"Ramo4:"<<a[3]<<" "<<"CODIGO4:"<<c[3]<<endl;
  archivo<<"Ramo5:"<<a[4]<<" "<<"CODIGO5:"<<c[4]<<endl;
	archivo<<"SECCION:"<<s[0]<<" "<<s[1]<<endl;
};

int main() {
	Ramo asig;
	int opc;
  int opc2;
  int opc3;
    do {
        cout<<"MENU:";
        cout<<"\n1- PROFESOR.";
        cout<<"\n2- ALUMNO.";
        cout<<"\n3- SALIR";
        cout<<"\n Opcion : ";
        cin>>opc;
        switch(opc) {

          case 1:            
            cout<<"\n1- Ingresar datos de profesor.";
            cout<<"\n2- Crear archivo con datos de profesor.";
            cout<<"\n3- Crear archivo con datos de alumno.";
            cout<<"\n Opcion : ";
            cin>>opc2;
            switch(opc2) { 
                 case 1:
                  asig.IngresarDatosP();
                  break;

                 case 2:
                  asig.CrearArchivoP();
                  break;

                 case 3:
                  asig.CrearArchivoE();
                  asig.IngresarNotasE();
                  
                  break;
               }
               break;

          

          case 2:
            cout<<"\n1- Ingresar datos de Alumno.";
			      cout<<"\n2- crear archivo de alumno.";
            cout<<"\n Opcion : ";
            cin>>opc3;
            switch(opc3) { 
                 case 1:
                  asig.IngresarDatosE();	
                  asig.IngresarNotasE();
                  break;

                 case 2:
                  asig.CrearArchivoE();
                  break; 
               }
               break;
        }
    } while(opc!=0);
  system("PAUSE" );
  return 0;

}