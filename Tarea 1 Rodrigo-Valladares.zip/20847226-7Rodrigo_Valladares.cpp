// nombre: Rodrigo Valladares; Rut: 20847226-7
// ncr: 8509


#include <iostream>
#include <fstream>
#include <cstring>
#include  <unistd.h>
#include <windows.h>

using namespace std;

class Persona
{
	public:
	string nom,rut,dir,telf,sex,edad;
	Persona(){ };
	~Persona(){ };
	void datosper();
	void mostrarper();
};
//esta funcion es para agregar los datos a las variables de la clase persona
void Persona::datosper(){
      getchar();
		  cout << "\nNombre completo: "; getline(cin, nom);
    	cout << "Rut : "; getline(cin, rut);
    	cout << "Direccion : " ; getline(cin, dir);
    	cout << "Telefono : " ; getline(cin, telf);
    	cout << "Sexo : "; getline(cin, sex);
    	cout << "Edad : "; getline(cin, edad);
	};

//esta funcion muestra en pantalla los datos de la clase persona
void Persona::mostrarper(){
		  cout << "\nNombre completo: "<<nom<<endl;
    	cout << "Rut : "<<rut<<endl;
    	cout << "Direccion : "<<dir<<endl;
    	cout << "Telefono : " <<telf<<endl;
    	cout << "Sexo : "; cout<<sex<<endl;
    	cout << "Edad : "; cout<<edad<<endl;
	};

class Profesor: public virtual Persona
{
	public:
	string cat;
	int cantidad;
	Profesor(){	};
	~Profesor(){ };
	void datosprof();
	void mostrarprof();
	void entregarnotas();
};

void Profesor::datosprof() {
		datosper();
	};
void Profesor::mostrarprof(){
		mostrarper();
	};

class Estudiante: public virtual Persona
{
	public:
	string carr;
	Estudiante(){ };
	~Estudiante(){ };
	void datosest();
	void mostrarest();
};

void Estudiante::datosest() {  //funcion para ingresar datos para estudiantes
		datosper();
		cout<<"Ingresar Carrera que Estudia: ";
		getline(cin,carr);
	};
void Estudiante::mostrarest(){  //funcion para imprimir datos de estudiante
		mostrarper();
		cout<<"Carrera: "<<carr;
	};

class Asignatura: public Profesor, public Estudiante
{
	public:
	string s[10];
	string a[10],c[10];
  string NombreAsignatura[10];
	int cantidad;
	string mat[5]={"PROGRAMACION","BASE DE DATOS","ALGORITMO Y ESTRUCTURA DE DATOS","DESARROLLO WEB Y MOBIL","PARADIGMAS DE PROGRAMACION"};
	string cod[5]={"PR001","BD002","AE003","DM004","PP005"};
	Asignatura();
	~Asignatura();
	void ingresardatosEstudiante();
	void mostrarNotEstudiante();
	void ingresardatosProfesor();
  void ingresoNotas();
};

void Asignatura::ingresardatosProfesor(){ //funcion para ingresar datos de profesor
	int opcion,opc;
	datosprof();
	cout<<"Escriba la Cantidad de Asignaturas: ";cin>> cantidad;
	for (int i=0;i<cantidad;i++){//for para repetir hasta que se ingresen todas las asignaturas
		cout<<"Seleccione las Asignaturas: ";
		cout<<"\n 1. "<<mat[0];
		cout<<"\n 2. "<<mat[1];
		cout<<"\n 3. "<<mat[2];
		cout<<"\n 4. "<<mat[3];
		cout<<"\n 5. "<<mat[4];
		cout<<"\n Seleccione una Opcion: ";
		cin>>opcion;
		switch (opcion){
			case 1: {
			a[i]=mat[0];
			c[i]=cod[0];
			break;
			}
			case 2: {
			a[i]=mat[1];
			c[i]=cod[1];
			break;
			}
			case 3: {
			a[i]=mat[2];
			c[i]=cod[2];
			break;
			}
			case 4: {
			a[i]=mat[3];
			c[i]=cod[3];
			break;
			}
			case 5: {
			a[i]=mat[4];
			c[i]=cod[4];
			break;
			}
			}

		cout<<"\n 1. Seccion 1";
		cout<<"\n 2. Seccion 2";
		cout<<"\n Seleccione la seccion: ";
		cin>>opc;
		switch (opc){
			case 1: {
				s[i]="1";
				break;
			}
			case 2: {
				s[i]="2";
				break;
			}
		}
 	}
};



void Asignatura::ingresoNotas() //funcion para ingresar notas a un archivos de txt para ser entregado
{
  string nomComEst,opcion;
  bool paraW=true;
  string notas[4] = {"1 ","2 ","3 ","4 "};
  float nota;


  while(paraW == true)
  {
    opcion ="y";
    if (opcion == "y")
    {
      for(int i=0;i<cantidad;i++){
      cout<<"Ingrese notas para "<<a[i]<<" Seccion "<<s[i]<<endl;
      NombreAsignatura[i] = a[i]+s[i];//a es asignatura y s seccion
      ofstream archivo(NombreAsignatura[i]+".txt");
        while(true)
          {
            cout << "Escriba nombre completo del estudiante: ";cin>>nomComEst;
            archivo<<nomComEst;
            for(int j=0;j<4;j++){
              cout<<notas[j]<<"nota: ";
              cin>>nota;
              if((nota>=1) && (nota<=7)){
                archivo<<" "<<nota;
                }
              else{
                cout<<"la nota ingresada no esta en el rango o no es valido"<<endl;
                j--;
              }
        }
        archivo<<"\n";
        cout<<"Agregara mas estudiantes (y) (n)"<<endl;
        cin>>opcion;
        if(opcion == "n"){
          paraW = false;
          break;
        }
        }
      archivo.close();
      }
      }



    }

}




void Asignatura::mostrarNotEstudiante(){ // funcion para avisar que ya hay notas subidas

  cout << "su profesor ya subio su nota revisar archivos de texto: ";
}
Asignatura::Asignatura(){
};
Asignatura::~Asignatura(){
};


int main() {

  Asignatura profe,estudiante;  //aca se asignan los nombres que tendran las clases para que sean llamadas
  bool M1=false,M2=false,M3=false,main=true;
  int opcion;


  while(main==true){  //menu para poder llamar todo en el main
    cout<<"\n MENU";
		cout<<"\n 1. PROFESOR";
		cout<<"\n 2. ESTUDIANTE";
    cout<<"\n 3. SALIR";
		cout<<"\n Seleccione una Opcion: ";cin>>opcion;
    switch(opcion){
      case 1:{
        cout<<"\nMENU PROFESOR";
        cout<<"\n1. Ingresar datos profesor";
		    cout<<"\n2. Mostrar datos de profesor";
		    cout<<"\n3. Ingresar notas";
        cout<<"\n4. Salir a menu principal";
        cout<<"\nSeleccione una opcion: ";cin>>opcion;
        switch(opcion){
          case 1:{
            profe.ingresardatosProfesor();
            M1 = true;
            break;
          }
          case 2:{
            if (M1)
              profe.mostrarprof();
            else
              cout<<" No hay datos del profesor.";
            break;
          }
          case 3:{
            if(M1){
              profe.ingresoNotas();
              M2 = true;
              }
            else
              cout<<" No hay datos del profesor.";
            break;
          }
          case 4:{
            break;
          }
        }
        break;
      }
      case 2:{
        cout<<"\n MENU ESTUDIANTE";
        cout<<"\n1.Ingresar datos estudiante";
		    cout<<"\n2.Mostrar datos de estudiante";
        cout<<"\n3.Mostrar notas";
        cout<<"\n4.Salir a menu principal";
        cout<<"\nSeleccione una opcion: ";cin>>opcion;
        switch(opcion){
          case 1:{
            estudiante.datosest();
            M3 = true;
            break;
          }
          case 2:{
            if (M3)
              estudiante.mostrarest();
            else
              cout<<"\nNo hay datos del estudiante.";
            break;
          }
          case 3:{
            if(M2 && M3)
              estudiante.mostrarNotEstudiante();
            else
              cout<<"\nno hay datos de estudiante o faltan ingresar sus notas.";
            break;
          }
          case 4:{
            break;
          }
        }
        break;
      }
      case 3:{
        cout << "cerrando programa";
        sleep(1);
        cout << "\n.";
        sleep(1);
        cout << "\n..";
        sleep(1);
        cout << "\n...";
        main=false;
      }
    }
  }
  return 0;

}
