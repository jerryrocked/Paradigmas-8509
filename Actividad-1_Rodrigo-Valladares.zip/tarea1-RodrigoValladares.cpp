//Rodrigo Ignacio Valladares Fuenzalida

#include<iostream>
#include<string.h>
#include<fstream>

using namespace std;
//Tarea , convertir notas de string a reales y guardarlas en arreglos

int main() {
    int k = 0,y=0,p=0,t=0,cont=0;
    float arrNot[40];  //en este arreglo se guardaran las notas
    string arrNom[40];//este arreglo tendra los nombres
    string archivo1="texto1.txt";
    ifstream archivo(archivo1.c_str());
    string linea,nomb,n1,n2,n3,n4;
    int res,lon,i,j=0;
    string arreglo[100];
    char b,l;
    float nota1,nota2,nota3,nota4;
    while (getline(archivo,linea)) {
      //cout<<linea<<endl;
      lon = linea.length();
      for (i=0;i<lon;i++){
          l=linea[i];
          b=' ';
          if (l!=b){
              if (j==0)
                  nomb=nomb+linea[i];
              if (j==1)
                  n1=n1+linea[i];
              if (j==2)
                  n2=n2+linea[i];
              if (j==3)
                  n3=n3+linea[i];
              if (j==4)
                  n4=n4+linea[i];
          }
          else
              j++;
        }
      cout<<nomb<<endl;
      cout<<n1<<endl;
      cout<<n2<<endl;
      cout<<n3<<endl;
      cout<<n4<<endl;
      j=0;

      arrNom[y]=nomb; //aca se guardan los nombres

      //aca se convierten las notas
      nota1 = stoi(n1);
      nota2 = stoi(n2);
      nota3 = stoi(n3);
      nota4 = stoi(n4);


      // aca se asignan las notas al arreglo
      arrNot[k]= nota1;
      k++;
      arrNot[k]= nota2;
      k++;
      arrNot[k]= nota3;
      k++;
      arrNot[k]= nota4;
      k++;

      nomb="";
      n1="";
      n2="";
      n3="";
      n4="";

      y++;
    }
    cout << "nombres guardados en arreglos: "<<endl;
    //este for es para mostrar los nombres
    for(p=0; p<8;p++){
      cout<<arrNom[p]<<endl;
    }
    cout << "notas guardadas en arreglos: "<<endl;
    //este for es para mostrar las notas
    for(t=0; t<k;t++){
      cont ++;
      cout<<arrNot[t]<<endl;
      if(cont==4)//este if es para que se diferencien mejor las notas de cada alumno
      {
        cout << endl;
        cont =0;
      }


    }

  return 0;
  }
