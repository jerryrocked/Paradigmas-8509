package com.mycompany.act3;
import java.util.Scanner;
/**
 *
 * @author Bryan
 */
public class Act3 {

    public static void main(String[] args) {
        int Monto;
        double MontoTotal;
        int Opcion;
        int Meses;
        Boolean x = true;
        System.out.println("----------Bienvenido a al banco XYZ----------");
        System.out.println("Elija una opcion: ");
        System.out.println("1.- Cuenta de ahorro\n2.- Cuenta corriente\n3.- Cuenta de plazo fijo");
        Scanner entrada = new Scanner(System.in);
        System.out.println("Seleccione su opcion:");
        double Porcentaje;
        Opcion = entrada.nextInt();
        if (Opcion == 3){
            System.out.println("Elija la duracion de su plazo fijo:\n1. 3 meses\n2. 6 meses");
            Meses = entrada.nextInt();
            
           while(x){
               if(Meses == 1 | Meses ==2){
                   x = false;
                   Porcentaje = 1.12;
                   if(Meses ==1){
                   System.out.println("Ingrese la cantidad a ahorrar: ");
                   Monto = entrada.nextInt();
                   MontoTotal = Monto * Porcentaje * 3;
                   System.out.println("Su ganancia total: "+ MontoTotal);
                   }
                   if(Meses ==2){
                    System.out.println("Ingrese la cantidad a ahorrar: ");
                    Monto = entrada.nextInt();
                    MontoTotal = Monto * Porcentaje * 6;
                    System.out.println("Su ganancia total: "+ MontoTotal);    
                   }
               }else{
                   System.out.println("Error. Por favor ingresar opcion valida...");
                   System.out.println("Elija la duracion de su plazo fijo:\n1.- 3 meses\n2.- 6 meses");
                   Meses = entrada.nextInt();
                           
               }
               
           }
        }
        
        if(Opcion == 1){
            Porcentaje = 1.01;
            System.out.println("Ingrese la cantidad a ahorrar: ");
            Monto = entrada.nextInt();
            MontoTotal = Monto * Porcentaje;
            System.out.println("Su ganancia total: "+ MontoTotal);
        }
        if(Opcion ==2){
            Porcentaje = 1.005;
            System.out.println("Ingrese la cantidad a ahorrar: ");
            Monto = entrada.nextInt();
            MontoTotal = Monto * Porcentaje;
            System.out.println("Su ganancia total: "+ MontoTotal);
        }
        
        
    }
}
