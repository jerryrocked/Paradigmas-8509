#include <iostream>
#include  <fstream>
#include <string.h>

using namespace std;


int main() {
  string nameArchivo = "text.txt";
  ifstream archivo(nameArchivo.c_str());
  string linea, name, n1, n2, n3, n4;
  int res, j, i=0, lon;
  string arreglo[100];
  char b, l;
  int n1a = 0;
  int n;

  while(getline(archivo, linea)){
    cout<<linea<<endl;
    lon = linea.length();
    int n1a,n2a,n3a,n4a;
      for(j=0;j<lon;j++){

        l =linea[j];
        b=' ';
        if(l!=b){
          if(i==0)
            name+=linea[j];
          if(i==1)
            n1+=linea[j];
            n1a = atoi(n1.c_str());// Transformo char a int con atoi
          if(i==2)
            n2+=linea[j];
            n2a = atoi(n2.c_str());
          if(i==3)
            n3+=linea[j];
            n3a = atoi(n3.c_str());
          if(i==4)
            n4+=linea[j];
            n4a = atoi(n4.c_str());
            
        }
        else{
          arreglo[i]= name; //Aquí guardé los nombres en el array
          cout<<arreglo[i];
          i++;
        }
      }
    cout<<name<<endl;
    cout<<n1a<<endl;
    cout<<n2a<<endl;
    cout<<n3a<<endl;
    cout<<n4a<<endl;
    
    i=0;
    
    name = " ";
    n1= " ";
    n2= " ";
    n3= " ";
    n4= " ";
    
    }
}